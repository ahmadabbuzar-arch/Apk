package com.web2apk.template

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.RenderProcessGoneDetail
import android.webkit.SslErrorHandler
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.net.http.SslError
import android.widget.Button
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

/**
 * Hosts the bundled website inside a locked-down WebView.
 *
 * The site is always loaded from the APK's own assets. No Kotlin/Java objects
 * are exposed to JavaScript, and file/content access from web content is
 * disabled (android_asset URLs are not affected by those switches).
 */
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var loadingView: View
    private lateinit var errorView: View
    private var showingError = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        loadingView = findViewById(R.id.loadingView)
        errorView = findViewById(R.id.errorView)
        findViewById<Button>(R.id.retryButton).setOnClickListener { reload() }

        configureWebView()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!showingError && webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        val restored = savedInstanceState?.let { webView.restoreState(it) }
        if (restored == null) {
            webView.loadUrl(START_URL)
        }
    }

    @Suppress("DEPRECATION")
    private fun configureWebView() {
        with(webView.settings) {
            javaScriptEnabled = true      // required by the website
            domStorageEnabled = true      // localStorage / sessionStorage
            allowFileAccess = false       // does not affect file:///android_asset/
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            setGeolocationEnabled(false)
            builtInZoomControls = false
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
        }

        webView.webViewClient = object : WebViewClient() {

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return !isInternal(request.url) && openExternally(request.url)
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                showingError = false
                errorView.visibility = View.GONE
                loadingView.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView, url: String?) {
                if (!showingError) {
                    loadingView.visibility = View.GONE
                    view.visibility = View.VISIBLE
                }
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) showError()
            }

            // Android 5.x / 6.0 (API < 23) uses this older callback for page load errors.
            @Deprecated("Deprecated in Java")
            override fun onReceivedError(view: WebView?, errorCode: Int, description: String?, failingUrl: String?) {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M && failingUrl == START_URL) showError()
            }

            // Never continue after a certificate problem.
            override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
                handler.cancel()
            }

            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                showError()
                return true
            }
        }
    }

    private fun isInternal(uri: Uri): Boolean = uri.toString().startsWith(SITE_PREFIX)

    /** Opens https/mailto/tel links in the matching system app. Everything else is blocked. */
    private fun openExternally(uri: Uri): Boolean {
        when (uri.scheme?.lowercase()) {
            "https", "mailto", "tel" -> try {
                startActivity(Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE))
            } catch (_: ActivityNotFoundException) {
                // No app can handle the link; ignore it.
            }
        }
        return true // the WebView itself never navigates to external or non-site URLs
    }

    private fun showError() {
        showingError = true
        loadingView.visibility = View.GONE
        webView.visibility = View.INVISIBLE
        errorView.visibility = View.VISIBLE
    }

    private fun reload() {
        showingError = false
        errorView.visibility = View.GONE
        loadingView.visibility = View.VISIBLE
        webView.visibility = View.VISIBLE
        webView.loadUrl(START_URL)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    override fun onPause() {
        webView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        (webView.parent as? android.view.ViewGroup)?.removeView(webView)
        webView.destroy()
        super.onDestroy()
    }

    companion object {
        private const val SITE_PREFIX = "file:///android_asset/site/"
        private const val START_URL = "file:///android_asset/site/index.html"
    }
}
