#!/usr/bin/env node
'use strict';

/**
 * Validates an uploaded website ZIP without extracting it.
 *   node scripts/validate-site.js build-input/website.zip
 *
 * Rejects: path traversal, absolute paths, symlinks, blocked file types,
 * too many / too large files, and archives without index.html.
 * The website is never executed.
 */

const fs = require('fs');
const { scanZip, ZipValidationError } = require('./lib/safeZip');
const { run, userError } = require('./lib/cli');

const MAX_ZIP_BYTES = 20 * 1024 * 1024;

async function validateSite(zipPath) {
  let stat;
  try {
    stat = await fs.promises.stat(zipPath);
  } catch (_) {
    throw userError('The website ZIP could not be found');
  }
  if (!stat.isFile()) throw userError('The website ZIP could not be found');
  if (stat.size > MAX_ZIP_BYTES) throw userError('Website ZIP must be smaller than 20 MB');

  const handle = await fs.promises.open(zipPath, 'r');
  const magic = Buffer.alloc(4);
  try {
    await handle.read(magic, 0, 4, 0);
  } finally {
    await handle.close();
  }
  if (magic.toString('hex') !== '504b0304') throw userError('The uploaded website file is not a ZIP archive');

  try {
    return await scanZip(zipPath);
  } catch (err) {
    if (err instanceof ZipValidationError) throw userError(err.message);
    throw err;
  }
}

module.exports = { validateSite };

if (require.main === module) {
  run(async () => {
    const zipPath = process.argv[2];
    if (!zipPath) throw userError('Usage: node scripts/validate-site.js <website.zip>');
    const info = await validateSite(zipPath);
    console.log(`Website ZIP is valid: ${info.fileCount} files, ${info.totalBytes} bytes, site root "${info.prefix || '/'}"`);
  });
}
