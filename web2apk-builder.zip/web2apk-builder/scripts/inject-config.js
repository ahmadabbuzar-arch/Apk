#!/usr/bin/env node
'use strict';

/**
 * Injects the app name, package name, launcher icon and optional splash image
 * into the Android template.
 *
 *   APP_NAME=... PACKAGE_NAME=... \
 *   node scripts/inject-config.js --template android-template \
 *        --icon build-input/icon.png [--splash build-input/splash.png]
 *
 * - App name     -> res/values/app_name.xml (XML/Android-escaped)
 * - Package name -> app-config.properties (read by app/build.gradle as applicationId)
 * - Icon         -> legacy, round and adaptive launcher icons for every density
 * - Splash       -> res/drawable-nodpi/splash_image.png (replaces the default drawable)
 *
 * The source package of the Kotlin code stays "com.web2apk.template"; Android
 * allows the applicationId to differ from the code namespace, so no source
 * files have to be rewritten.
 */

const fs = require('fs');
const path = require('path');
const sharp = require('sharp');
const { run, parseArgs, requireArg, userError } = require('./lib/cli');
const { validateAppName, validatePackageName, androidStringEscape } = require('./lib/rules');

const LEGACY_SIZES = { mdpi: 48, hdpi: 72, xhdpi: 96, xxhdpi: 144, xxxhdpi: 192 };
const ADAPTIVE_SIZES = { mdpi: 108, hdpi: 162, xhdpi: 216, xxhdpi: 324, xxxhdpi: 432 };
const ICON_MIN = 192;
const ICON_MAX = 1024;

async function readPng(filePath, label) {
  let metadata;
  try {
    metadata = await sharp(filePath, { failOn: 'error' }).metadata();
  } catch (_) {
    throw userError(`${label} is not a valid PNG image`);
  }
  if (metadata.format !== 'png') throw userError(`${label} must be a PNG image`);
  return metadata;
}

async function writeIcons(iconPath, resDir) {
  const meta = await readPng(iconPath, 'App icon');
  if (meta.width !== meta.height) throw userError('App icon must be square');
  if (meta.width < ICON_MIN || meta.width > ICON_MAX) {
    throw userError(`App icon must be between ${ICON_MIN}x${ICON_MIN} and ${ICON_MAX}x${ICON_MAX} pixels`);
  }

  for (const [density, size] of Object.entries(LEGACY_SIZES)) {
    const dir = path.join(resDir, `mipmap-${density}`);
    await fs.promises.mkdir(dir, { recursive: true });

    await sharp(iconPath).resize(size, size, { fit: 'cover' }).png({ compressionLevel: 9 }).toFile(path.join(dir, 'ic_launcher.png'));

    const mask = Buffer.from(`<svg width="${size}" height="${size}"><circle cx="${size / 2}" cy="${size / 2}" r="${size / 2}" fill="#fff"/></svg>`);
    await sharp(iconPath)
      .resize(size, size, { fit: 'cover' })
      .composite([{ input: mask, blend: 'dest-in' }])
      .png({ compressionLevel: 9 })
      .toFile(path.join(dir, 'ic_launcher_round.png'));
  }

  // Adaptive icon foreground: the artwork occupies the centre so launcher masks never cut it off.
  for (const [density, size] of Object.entries(ADAPTIVE_SIZES)) {
    const dir = path.join(resDir, `mipmap-${density}`);
    const inner = Math.round(size * 0.62);
    const pad = Math.floor((size - inner) / 2);
    await sharp(iconPath)
      .resize(inner, inner, { fit: 'cover' })
      .extend({ top: pad, bottom: size - inner - pad, left: pad, right: size - inner - pad, background: { r: 0, g: 0, b: 0, alpha: 0 } })
      .png({ compressionLevel: 9 })
      .toFile(path.join(dir, 'ic_launcher_foreground.png'));
  }
}

async function writeSplash(splashPath, resDir) {
  const meta = await readPng(splashPath, 'Splash image');
  if (meta.width < 200 || meta.height < 200 || meta.width > 4096 || meta.height > 4096) {
    throw userError('Splash image must be between 200 and 4096 pixels on each side');
  }
  const nodpi = path.join(resDir, 'drawable-nodpi');
  await fs.promises.mkdir(nodpi, { recursive: true });
  await sharp(splashPath)
    .resize({ width: 1080, height: 1920, fit: 'inside', withoutEnlargement: true })
    .png({ compressionLevel: 9 })
    .toFile(path.join(nodpi, 'splash_image.png'));
  // Remove the default (empty) drawable with the same resource name.
  await fs.promises.rm(path.join(resDir, 'drawable', 'splash_image.xml'), { force: true });
}

async function injectConfig({ templateDir, iconPath, splashPath, appName, packageName }) {
  const appDir = path.join(templateDir, 'app');
  const resDir = path.join(appDir, 'src', 'main', 'res');
  if (!fs.existsSync(resDir)) throw new Error(`Android template not found at ${templateDir}`);

  const valuesDir = path.join(resDir, 'values');
  await fs.promises.mkdir(valuesDir, { recursive: true });
  const xml =
    '<?xml version="1.0" encoding="utf-8"?>\n' +
    '<resources>\n' +
    `    <string name="app_name" formatted="false">${androidStringEscape(appName)}</string>\n` +
    '</resources>\n';
  await fs.promises.writeFile(path.join(valuesDir, 'app_name.xml'), xml, 'utf8');

  await fs.promises.writeFile(path.join(templateDir, 'app-config.properties'), `appId=${packageName}\n`, 'utf8');

  await writeIcons(iconPath, resDir);
  if (splashPath) await writeSplash(splashPath, resDir);
}

module.exports = { injectConfig };

if (require.main === module) {
  run(async () => {
    const args = parseArgs(process.argv.slice(2));
    const appName = validateAppName(process.env.APP_NAME);
    const packageName = validatePackageName(process.env.PACKAGE_NAME);
    await injectConfig({
      templateDir: requireArg(args, 'template'),
      iconPath: requireArg(args, 'icon'),
      splashPath: args.splash || null,
      appName,
      packageName,
    });
    console.log(`Injected app name "${appName}", package ${packageName}, launcher icons${args.splash ? ' and splash image' : ''}`);
  });
}
