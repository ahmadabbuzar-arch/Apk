#!/usr/bin/env node
'use strict';

/**
 * Creates ready-to-upload test files in ./examples:
 *   examples/test-icon.png        512x512 launcher icon
 *   examples/test-splash.png      1080x1920 splash image
 *   examples/sample-site.zip      ZIP containing examples/sample-site/index.html
 *
 *   node scripts/make-test-assets.js
 */

const fs = require('fs');
const path = require('path');
const { createZip, createPng } = require('./lib/zipWriter');

const examplesDir = path.resolve(__dirname, '..', 'examples');

function icon(size) {
  const c = size / 2;
  return (x, y) => {
    const t = (x + y) / (2 * size);
    const dx = x - c;
    const dy = y - c;
    const d = Math.sqrt(dx * dx + dy * dy);
    let r = Math.round(37 + t * 100);
    let g = Math.round(99 - t * 20);
    let b = Math.round(235 - t * 30);
    if (d < size * 0.3 && d > size * 0.2) [r, g, b] = [255, 255, 255];
    if (d <= size * 0.12) [r, g, b] = [255, 255, 255];
    return [r, g, b, 255];
  };
}

function splash(w, h) {
  return (x, y) => {
    const t = y / h;
    const dx = x - w / 2;
    const dy = y - h / 2;
    const d = Math.sqrt(dx * dx + dy * dy);
    const white = d < w * 0.16;
    return white ? [255, 255, 255, 255] : [Math.round(15 + t * 22), Math.round(23 + t * 40), Math.round(42 + t * 90), 255];
  };
}

fs.mkdirSync(examplesDir, { recursive: true });
fs.writeFileSync(path.join(examplesDir, 'test-icon.png'), createPng(512, 512, icon(512)));
fs.writeFileSync(path.join(examplesDir, 'test-splash.png'), createPng(1080, 1920, splash(1080, 1920)));

const indexHtml = fs.readFileSync(path.join(examplesDir, 'sample-site', 'index.html'));
fs.writeFileSync(path.join(examplesDir, 'sample-site.zip'), createZip([{ name: 'index.html', data: indexHtml }]));

console.log('Created examples/test-icon.png, examples/test-splash.png and examples/sample-site.zip');
