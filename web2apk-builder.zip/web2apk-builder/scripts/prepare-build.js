#!/usr/bin/env node
'use strict';

/**
 * Extracts the validated website into the Android template and writes config.json.
 *
 *   BUILD_ID=... APP_NAME=... PACKAGE_NAME=... \
 *   node scripts/prepare-build.js --zip build-input/website.zip \
 *        --template android-template --out build-output
 *
 * The website ends up in <template>/app/src/main/assets/site/ and is loaded by
 * the app from file:///android_asset/site/index.html.
 */

const fs = require('fs');
const path = require('path');
const { extractZip, ZipValidationError } = require('./lib/safeZip');
const { run, parseArgs, requireArg, userError } = require('./lib/cli');
const { validateBuildId, validateAppName, validatePackageName } = require('./lib/rules');

async function prepareBuild({ zipPath, templateDir, outDir, buildId, appName, packageName }) {
  const siteDir = path.join(templateDir, 'app', 'src', 'main', 'assets', 'site');
  if (!path.resolve(siteDir).startsWith(path.resolve(templateDir) + path.sep)) throw new Error('Invalid template path');

  // Start from an empty site folder so nothing from the template placeholder leaks in.
  await fs.promises.rm(siteDir, { recursive: true, force: true });
  await fs.promises.mkdir(siteDir, { recursive: true });

  let info;
  try {
    info = await extractZip(zipPath, siteDir);
  } catch (err) {
    if (err instanceof ZipValidationError) throw userError(err.message);
    throw err;
  }
  if (!fs.existsSync(path.join(siteDir, 'index.html'))) throw userError('index.html not found');

  const config = { buildId, appName, packageName, createdAt: new Date().toISOString() };
  await fs.promises.mkdir(outDir, { recursive: true });
  await fs.promises.writeFile(path.join(outDir, 'config.json'), `${JSON.stringify(config, null, 2)}\n`);
  return { info, config };
}

module.exports = { prepareBuild };

if (require.main === module) {
  run(async () => {
    const args = parseArgs(process.argv.slice(2));
    const result = await prepareBuild({
      zipPath: requireArg(args, 'zip'),
      templateDir: requireArg(args, 'template'),
      outDir: requireArg(args, 'out'),
      buildId: validateBuildId(process.env.BUILD_ID),
      appName: validateAppName(process.env.APP_NAME),
      packageName: validatePackageName(process.env.PACKAGE_NAME),
    });
    console.log(`Injected ${result.info.fileCount} website files into the Android assets`);
    console.log(`Wrote ${path.join(args.out, 'config.json')}`);
  });
}
