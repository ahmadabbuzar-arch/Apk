'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');

const { scanZip, extractZip, ZipValidationError } = require('../src/utils/safeZip');
const { createZip } = require('../../scripts/lib/zipWriter');

function tmpDir() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'w2a-test-'));
}

function writeZip(dir, entries) {
  const file = path.join(dir, 'site.zip');
  fs.writeFileSync(file, createZip(entries));
  return file;
}

const HTML = '<!doctype html><title>x</title>';

test('accepts a single-file website', async () => {
  const dir = tmpDir();
  const info = await scanZip(writeZip(dir, [{ name: 'index.html', data: HTML }]));
  assert.equal(info.fileCount, 1);
  assert.equal(info.prefix, '');
});

test('accepts index.html inside one top-level folder and extracts it flat', async () => {
  const dir = tmpDir();
  const zip = writeZip(dir, [
    { name: 'site/index.html', data: HTML },
    { name: 'site/css/app.css', data: 'body{}' },
  ]);
  const dest = path.join(dir, 'out');
  const info = await extractZip(zip, dest);
  assert.equal(info.prefix, 'site/');
  assert.equal(fs.readFileSync(path.join(dest, 'index.html'), 'utf8'), HTML);
  assert.ok(fs.existsSync(path.join(dest, 'css', 'app.css')));
});

test('reports missing index.html', async () => {
  const dir = tmpDir();
  await assert.rejects(scanZip(writeZip(dir, [{ name: 'readme.txt', data: 'hi' }])), (e) => e instanceof ZipValidationError && e.message === 'index.html not found');
});

test('blocks path traversal and absolute paths', async () => {
  for (const name of ['../evil.html', '../../evil.html', 'a/../../evil.html', '/etc/passwd', 'C:/evil.html', 'a\\..\\evil.html']) {
    const dir = tmpDir();
    await assert.rejects(scanZip(writeZip(dir, [{ name: 'index.html', data: HTML }, { name, data: 'x' }])), ZipValidationError, name);
  }
});

test('blocks symlinks', async () => {
  const dir = tmpDir();
  await assert.rejects(
    scanZip(writeZip(dir, [{ name: 'index.html', data: HTML }, { name: 'link', data: '/etc/passwd', symlink: true }])),
    /Symbolic links/
  );
});

test('blocks executable and server-side file types but allows client-side js', async () => {
  for (const name of ['run.exe', 'a.bat', 'a.cmd', 'x.sh', 'x.php', 'x.py', 'X.PHP']) {
    const dir = tmpDir();
    await assert.rejects(scanZip(writeZip(dir, [{ name: 'index.html', data: HTML }, { name, data: 'x' }])), /not allowed/, name);
  }
  const dir = tmpDir();
  const info = await scanZip(writeZip(dir, [{ name: 'index.html', data: HTML }, { name: 'js/app.js', data: 'console.log(1)' }]));
  assert.equal(info.fileCount, 2);
});

test('enforces file count and file size limits', async () => {
  const dir = tmpDir();
  const many = [{ name: 'index.html', data: HTML }, { name: 'a.txt', data: 'a' }, { name: 'b.txt', data: 'b' }];
  await assert.rejects(scanZip(writeZip(dir, many), { maxFiles: 2 }), /more than 2 files/);
  const big = [{ name: 'index.html', data: HTML }, { name: 'big.bin', data: Buffer.alloc(2048) }];
  await assert.rejects(scanZip(writeZip(dir, big), { maxFileBytes: 1024 }), /too large/);
});

test('rejects files that are not ZIP archives', async () => {
  const dir = tmpDir();
  const file = path.join(dir, 'fake.zip');
  fs.writeFileSync(file, 'definitely not a zip');
  await assert.rejects(scanZip(file), /not a valid ZIP/);
});
