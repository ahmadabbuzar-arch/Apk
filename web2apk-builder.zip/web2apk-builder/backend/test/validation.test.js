'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('crypto');

const { validateAppName, validatePackageName, ValidationError } = require('../src/utils/validation');
const { verifyGithubSignature, slugify, generateBuildId, isValidBuildId, safeEqual } = require('../src/utils/security');

test('package names: accepts valid identifiers', () => {
  for (const ok of ['com.company.myapp', 'org.example.app_2', 'io.github.user.tool']) {
    assert.equal(validatePackageName(ok), ok);
  }
});

test('package names: rejects invalid identifiers', () => {
  const bad = ['myapp', 'Com.Company.App', 'com..app', '1com.app.x', 'com.company.', 'com.int.app', 'com.my-app.x', 'com.app x', '../../etc', ''];
  for (const value of bad) {
    assert.throws(() => validatePackageName(value), ValidationError, value);
  }
});

test('app names: sanitizes and enforces length', () => {
  assert.equal(validateAppName('  My   <b>App</b>  '), 'My bApp/b');
  assert.equal(validateAppName('Café ☕'), 'Café ☕');
  assert.throws(() => validateAppName(''), ValidationError);
  assert.throws(() => validateAppName('   '), ValidationError);
  assert.throws(() => validateAppName('x'.repeat(51)), ValidationError);
  assert.equal(validateAppName('x'.repeat(50)).length, 50);
  assert.throws(() => validateAppName(undefined), ValidationError);
});

test('webhook signatures are verified', () => {
  const secret = 'top-secret';
  const body = Buffer.from('{"hello":"world"}');
  const good = `sha256=${crypto.createHmac('sha256', secret).update(body).digest('hex')}`;
  assert.equal(verifyGithubSignature(body, good, secret), true);
  assert.equal(verifyGithubSignature(body, good.replace(/.$/, '0'), secret), false);
  assert.equal(verifyGithubSignature(body, good, 'other'), false);
  assert.equal(verifyGithubSignature(body, undefined, secret), false);
  assert.equal(verifyGithubSignature(body, good, ''), false);
});

test('build ids are random and well formed', () => {
  const a = generateBuildId();
  assert.ok(isValidBuildId(a));
  assert.notEqual(a, generateBuildId());
  assert.equal(isValidBuildId('../etc/passwd'), false);
  assert.equal(safeEqual('a', 'a'), true);
  assert.equal(safeEqual('a', 'b'), false);
});

test('slugify produces header-safe file names', () => {
  assert.equal(slugify('My Cool App!'), 'my-cool-app');
  assert.equal(slugify('日本語'), 'app');
  assert.equal(slugify('"; rm -rf /'), 'rm-rf');
});
