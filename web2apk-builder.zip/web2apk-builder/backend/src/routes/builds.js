'use strict';

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const express = require('express');
const multer = require('multer');
const rateLimit = require('express-rate-limit');

const { ValidationError } = require('../utils/validation');
const { isValidBuildId, safeEqual, bearerToken, slugify } = require('../utils/security');
const { APK_CONTENT_TYPE } = require('../services/buildService');

const INPUT_FILES = {
  website: { name: 'website.zip', type: 'application/zip' },
  icon: { name: 'icon.png', type: 'image/png' },
  splash: { name: 'splash.png', type: 'image/png' },
};

function limiter(limit, windowMs) {
  return rateLimit({
    windowMs,
    limit,
    standardHeaders: true,
    legacyHeaders: false,
    message: { success: false, error: 'Too many requests. Please slow down and try again later.' },
  });
}

function createBuildsRouter({ config, buildService, storage }) {
  const router = express.Router();

  const tmpDir = path.join(config.storagePath, 'tmp');
  fs.mkdirSync(tmpDir, { recursive: true });

  const upload = multer({
    storage: multer.diskStorage({
      destination: (req, file, cb) => cb(null, tmpDir),
      // The client supplied file name is never used.
      filename: (req, file, cb) => cb(null, crypto.randomBytes(16).toString('hex')),
    }),
    limits: { fileSize: config.limits.maxZipBytes, files: 3, fields: 8, fieldSize: 4096, parts: 16 },
    fileFilter: (req, file, cb) => {
      if (Object.prototype.hasOwnProperty.call(INPUT_FILES, file.fieldname)) return cb(null, true);
      return cb(new ValidationError('Unexpected file field in the upload'));
    },
  }).fields([
    { name: 'website', maxCount: 1 },
    { name: 'icon', maxCount: 1 },
    { name: 'splash', maxCount: 1 },
  ]);

  const createLimiter = limiter(config.buildRateLimitPerHour, 60 * 60 * 1000);
  const readLimiter = limiter(120, 60 * 1000);
  const actionLimiter = limiter(30, 60 * 60 * 1000);

  function idParam(req, res, next, id) {
    if (!isValidBuildId(id)) return next(new ValidationError('Build not found', 404));
    return next();
  }
  router.param('id', idParam);

  // POST /api/builds
  router.post('/', createLimiter, upload, async (req, res, next) => {
    const files = req.files || {};
    const tempPaths = Object.values(files).flat().map((f) => f.path);
    try {
      const result = await buildService.createBuild({
        appName: req.body.appName,
        packageName: req.body.packageName,
        website: (files.website || [])[0],
        icon: (files.icon || [])[0],
        splash: (files.splash || [])[0],
      });
      res.status(201).json({ success: true, buildId: result.id, status: result.status });
    } catch (err) {
      next(err);
    } finally {
      await Promise.all(tempPaths.map((p) => fs.promises.rm(p, { force: true }).catch(() => {})));
    }
  });

  // GET /api/builds/:id
  router.get('/:id', readLimiter, async (req, res, next) => {
    try {
      const build = await buildService.getPublicBuild(req.params.id);
      if (!build) throw new ValidationError('Build not found', 404);
      res.set('Cache-Control', 'no-store');
      res.json({ success: true, build });
    } catch (err) {
      next(err);
    }
  });

  // GET /api/builds/:id/download
  router.get('/:id/download', readLimiter, async (req, res, next) => {
    try {
      const build = await buildService.db.getBuild(req.params.id);
      if (!build) throw new ValidationError('Build not found', 404);
      if (build.status !== 'completed' || !build.apkKey) throw new ValidationError('The APK is not available yet', 409);

      const filename = `${slugify(build.appName)}.apk`;
      const redirectUrl = await storage.getDownloadUrl(build.apkKey, { filename });
      if (redirectUrl) return res.redirect(302, redirectUrl);

      const stat = await storage.stat(build.apkKey);
      if (!stat) throw new ValidationError('The APK file is no longer available', 410);

      res.set({
        'Content-Type': APK_CONTENT_TYPE,
        'Content-Length': String(stat.size),
        'Content-Disposition': `attachment; filename="${filename}"`,
        'X-Content-Type-Options': 'nosniff',
        'Cache-Control': 'private, max-age=0, no-cache',
      });
      const stream = storage.createReadStream(build.apkKey);
      stream.on('error', next);
      return stream.pipe(res);
    } catch (err) {
      return next(err);
    }
  });

  // GET /api/builds/:id/input/:kind - used only by the GitHub Actions runner.
  // Protected by a per-build bearer token that is invalidated when the build ends.
  router.get('/:id/input/:kind', async (req, res, next) => {
    try {
      const entry = Object.prototype.hasOwnProperty.call(INPUT_FILES, req.params.kind) ? INPUT_FILES[req.params.kind] : null;
      const build = await buildService.db.getBuild(req.params.id);
      const token = bearerToken(req);
      if (!entry || !build || build.status !== 'building' || !build.inputToken || !safeEqual(token, build.inputToken)) {
        throw new ValidationError('Forbidden', 403);
      }
      const key = `builds/${build.id}/${entry.name}`;
      const stat = await storage.stat(key);
      if (!stat) throw new ValidationError('Input file not found', 404);
      res.set({
        'Content-Type': entry.type,
        'Content-Length': String(stat.size),
        'Cache-Control': 'no-store',
        'X-Content-Type-Options': 'nosniff',
      });
      const stream = storage.createReadStream(key);
      stream.on('error', next);
      stream.pipe(res);
    } catch (err) {
      next(err);
    }
  });

  // POST /api/builds/:id/cancel
  router.post('/:id/cancel', actionLimiter, async (req, res, next) => {
    try {
      const build = await buildService.cancelBuild(req.params.id);
      res.json({ success: true, build });
    } catch (err) {
      next(err);
    }
  });

  // POST /api/builds/:id/retry
  router.post('/:id/retry', actionLimiter, async (req, res, next) => {
    try {
      const build = await buildService.retryBuild(req.params.id);
      res.json({ success: true, build });
    } catch (err) {
      next(err);
    }
  });

  return router;
}

module.exports = { createBuildsRouter };
