'use strict';

const express = require('express');
const log = require('../utils/logger');
const { verifyGithubSignature } = require('../utils/security');

/**
 * POST /api/github/webhook
 *
 * Receives "workflow_run" events from the GitHub repository webhook. The raw
 * body is needed for HMAC verification, so this router uses express.raw().
 */
function createGithubRouter({ config, buildService }) {
  const router = express.Router();

  router.post('/webhook', express.raw({ type: '*/*', limit: '1mb' }), (req, res) => {
    if (!config.webhookSecret) {
      return res.status(503).json({ success: false, error: 'Webhook is not configured' });
    }
    if (!verifyGithubSignature(req.body, req.get('x-hub-signature-256'), config.webhookSecret)) {
      return res.status(401).json({ success: false, error: 'Invalid signature' });
    }

    const event = req.get('x-github-event');
    if (event === 'ping') return res.json({ success: true, message: 'pong' });
    if (event !== 'workflow_run') return res.status(202).json({ success: true, ignored: true });

    let payload;
    try {
      payload = JSON.parse(req.body.toString('utf8'));
    } catch (_) {
      return res.status(400).json({ success: false, error: 'Invalid JSON payload' });
    }

    const run = payload && payload.workflow_run;
    const fullName = payload && payload.repository && payload.repository.full_name;
    const expectedPath = `.github/workflows/${config.githubWorkflow}`;
    const sameRepo = typeof fullName === 'string' && fullName.toLowerCase() === `${config.githubOwner}/${config.githubRepo}`.toLowerCase();
    const sameWorkflow = run && typeof run.path === 'string' && run.path.startsWith(expectedPath);
    if (!run || !sameRepo || !sameWorkflow) return res.status(202).json({ success: true, ignored: true });

    // Answer immediately (GitHub times out after 10s); the heavy work continues in the background.
    res.status(202).json({ success: true });
    buildService.handleWorkflowRun(run).catch((err) => log.error('Webhook processing failed', err.message));
    return undefined;
  });

  return router;
}

module.exports = { createGithubRouter };
