'use strict';

const express = require('express');

/** GET /api/health - never exposes secrets, only booleans. */
function createHealthRouter({ config }) {
  const router = express.Router();
  router.get('/', (req, res) => {
    res.json({
      success: true,
      status: 'ok',
      uptimeSeconds: Math.round(process.uptime()),
      githubConfigured: config.githubConfigured,
      webhookConfigured: Boolean(config.webhookSecret),
      maxConcurrentBuilds: config.maxConcurrentBuilds,
    });
  });
  return router;
}

module.exports = { createHealthRouter };
