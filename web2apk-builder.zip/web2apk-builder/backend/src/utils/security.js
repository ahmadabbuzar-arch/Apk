'use strict';

const crypto = require('crypto');

const BUILD_ID_RE = /^[a-f0-9]{32}$/;

/** 128 bits of randomness: unguessable, so the ID acts as a capability. */
function generateBuildId() {
  return crypto.randomBytes(16).toString('hex');
}

/** 256-bit token that lets the GitHub runner download one build's input files. */
function generateToken() {
  return crypto.randomBytes(32).toString('hex');
}

function isValidBuildId(value) {
  return typeof value === 'string' && BUILD_ID_RE.test(value);
}

/** Constant-time string comparison (hashes first so lengths never leak). */
function safeEqual(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  const ha = crypto.createHash('sha256').update(a).digest();
  const hb = crypto.createHash('sha256').update(b).digest();
  return crypto.timingSafeEqual(ha, hb);
}

/** Verifies the X-Hub-Signature-256 header GitHub sends with webhooks. */
function verifyGithubSignature(rawBody, signatureHeader, secret) {
  if (!secret || !signatureHeader || !Buffer.isBuffer(rawBody)) return false;
  const expected = `sha256=${crypto.createHmac('sha256', secret).update(rawBody).digest('hex')}`;
  return safeEqual(expected, signatureHeader);
}

/** ASCII-only, filesystem- and header-safe slug used for APK file names. */
function slugify(name) {
  const slug = String(name)
    .normalize('NFKD')
    .replace(/[^\x00-\x7F]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40);
  return slug || 'app';
}

function bearerToken(req) {
  const header = req.get('authorization') || '';
  const match = /^Bearer\s+([A-Za-z0-9._~+/-]+=*)$/.exec(header);
  return match ? match[1] : '';
}

module.exports = {
  generateBuildId,
  generateToken,
  isValidBuildId,
  safeEqual,
  verifyGithubSignature,
  slugify,
  bearerToken,
};
