'use strict';

/**
 * Safe ZIP scanning / extraction.
 *
 * This file is shared by the backend (upload-time validation) and the build
 * scripts (extraction inside GitHub Actions). scripts/lib/safeZip.js is an
 * identical copy - keep both in sync.
 *
 * Nothing inside the archive is ever executed. Every entry is checked for:
 *  - path traversal ("../"), absolute paths, backslashes, NUL bytes
 *  - symbolic links and special files
 *  - encrypted entries
 *  - blocked server-side / executable extensions
 *  - entry count, per-file size and total size (measured on the real
 *    decompressed byte stream, not just the sizes declared in the archive)
 */

const fs = require('fs');
const path = require('path');
const yauzl = require('yauzl');

const LIMITS = Object.freeze({
  maxFiles: 1000,
  maxFileBytes: 10 * 1024 * 1024,
  maxTotalBytes: 200 * 1024 * 1024,
});

const BLOCKED_EXTENSIONS = new Set(['.exe', '.bat', '.cmd', '.sh', '.php', '.py']);

class ZipValidationError extends Error {
  constructor(message) {
    super(message);
    this.name = 'ZipValidationError';
    this.userFacing = true;
  }
}

function show(name) {
  return String(name).replace(/[^\x20-\x7E]/g, '?').slice(0, 80);
}

function normalizeEntryName(raw) {
  if (raw.includes('\0')) throw new ZipValidationError('ZIP contains an invalid file name');
  if (raw.includes('\\')) throw new ZipValidationError(`Unsafe path in ZIP: ${show(raw)}`);
  if (raw.startsWith('/') || /^[A-Za-z]:/.test(raw)) {
    throw new ZipValidationError(`Absolute paths are not allowed in ZIP: ${show(raw)}`);
  }
  const parts = raw.split('/').filter((part) => part !== '' && part !== '.');
  if (parts.includes('..')) {
    throw new ZipValidationError(`Path traversal is not allowed in ZIP: ${show(raw)}`);
  }
  return parts;
}

function isIgnored(parts) {
  const last = parts[parts.length - 1];
  return parts[0] === '__MACOSX' || last === '.DS_Store' || last === 'Thumbs.db';
}

function pump(zip, entry, lim, state, outPath, name) {
  return new Promise((resolve, reject) => {
    zip.openReadStream(entry, (err, readStream) => {
      if (err) return reject(new ZipValidationError(`Corrupt entry in ZIP: ${show(name)}`));
      let bytes = 0;
      let done = false;
      const writeStream = outPath ? fs.createWriteStream(outPath, { flags: 'wx', mode: 0o644 }) : null;

      const finish = (error) => {
        if (done) return;
        done = true;
        if (error) {
          readStream.destroy();
          if (writeStream) writeStream.destroy();
          reject(error);
        } else {
          resolve();
        }
      };

      readStream.on('data', (chunk) => {
        bytes += chunk.length;
        state.total += chunk.length;
        if (bytes > lim.maxFileBytes) {
          finish(new ZipValidationError(`File too large (max ${Math.round(lim.maxFileBytes / 1048576)} MB): ${show(name)}`));
        } else if (state.total > lim.maxTotalBytes) {
          finish(new ZipValidationError('The extracted website is too large'));
        }
      });
      readStream.on('error', () => finish(new ZipValidationError(`Corrupt entry in ZIP: ${show(name)}`)));

      if (writeStream) {
        writeStream.on('error', (e) => {
          finish(e.code === 'EEXIST' ? new ZipValidationError(`Duplicate file in ZIP: ${show(name)}`) : e);
        });
        writeStream.on('finish', () => finish());
        readStream.pipe(writeStream);
      } else {
        readStream.on('end', () => finish());
      }
    });
  });
}

async function handleEntry(zip, entry, lim, state, dest, prefix) {
  const parts = normalizeEntryName(entry.fileName);
  if (parts.length === 0 || isIgnored(parts)) return;

  if (entry.isEncrypted()) throw new ZipValidationError('Encrypted ZIP files are not supported');

  const unixMode = (entry.externalFileAttributes >>> 16) & 0xffff;
  const unixType = unixMode & 0xf000;
  if (unixType === 0xa000) {
    throw new ZipValidationError(`Symbolic links are not allowed in ZIP: ${show(entry.fileName)}`);
  }
  if (entry.fileName.endsWith('/')) return; // directories are created on demand
  if (unixType !== 0 && unixType !== 0x8000) {
    throw new ZipValidationError(`Special files are not allowed in ZIP: ${show(entry.fileName)}`);
  }

  const name = parts.join('/');
  const key = name.toLowerCase();
  if (state.seen.has(key)) throw new ZipValidationError(`Duplicate file in ZIP: ${show(name)}`);
  state.seen.add(key);

  if (state.files.length >= lim.maxFiles) {
    throw new ZipValidationError(`ZIP contains more than ${lim.maxFiles} files`);
  }
  const ext = path.extname(name).toLowerCase();
  if (BLOCKED_EXTENSIONS.has(ext)) {
    throw new ZipValidationError(`File type "${ext}" is not allowed in a website ZIP: ${show(name)}`);
  }
  if (entry.uncompressedSize > lim.maxFileBytes) {
    throw new ZipValidationError(`File too large (max ${Math.round(lim.maxFileBytes / 1048576)} MB): ${show(name)}`);
  }
  state.files.push(name);

  let outPath = null;
  if (dest) {
    if (!name.startsWith(prefix)) throw new ZipValidationError(`Unexpected file location in ZIP: ${show(name)}`);
    const root = path.resolve(dest);
    outPath = path.resolve(root, ...name.slice(prefix.length).split('/'));
    if (!outPath.startsWith(root + path.sep)) {
      throw new ZipValidationError(`Path traversal is not allowed in ZIP: ${show(name)}`);
    }
    await fs.promises.mkdir(path.dirname(outPath), { recursive: true });
  }
  await pump(zip, entry, lim, state, outPath, name);
}

function walk(zipPath, limits, { dest = null, prefix = '' } = {}) {
  const lim = { ...LIMITS, ...limits };
  return new Promise((resolve, reject) => {
    yauzl.open(
      zipPath,
      { lazyEntries: true, autoClose: true, validateEntrySizes: true, strictFileNames: false, decodeStrings: true },
      (err, zip) => {
        if (err) return reject(new ZipValidationError('The file is not a valid ZIP archive'));
        const state = { files: [], seen: new Set(), total: 0 };
        let settled = false;

        const fail = (error) => {
          if (settled) return;
          settled = true;
          try { zip.close(); } catch (_) { /* already closed */ }
          reject(error instanceof ZipValidationError ? error : new ZipValidationError('The ZIP archive is corrupt or unreadable'));
        };

        zip.on('error', fail);
        zip.on('end', () => {
          if (settled) return;
          settled = true;
          resolve(state);
        });
        zip.on('entry', (entry) => {
          handleEntry(zip, entry, lim, state, dest, prefix).then(() => {
            if (!settled) zip.readEntry();
          }, fail);
        });
        zip.readEntry();
      }
    );
  });
}

/** Returns the folder prefix that holds index.html ('' or 'folder/'). */
function findSiteRoot(files) {
  if (files.includes('index.html')) return '';
  const tops = new Set(files.map((f) => f.split('/')[0]));
  if (tops.size === 1) {
    const top = [...tops][0];
    if (files.includes(`${top}/index.html`)) return `${top}/`;
  }
  throw new ZipValidationError('index.html not found');
}

/** Validates the whole archive without writing anything to disk. */
async function scanZip(zipPath, limits = {}) {
  const state = await walk(zipPath, limits);
  const prefix = findSiteRoot(state.files);
  return { fileCount: state.files.length, totalBytes: state.total, prefix, files: state.files };
}

/** Validates, then extracts the website into destDir. */
async function extractZip(zipPath, destDir, limits = {}) {
  const info = await scanZip(zipPath, limits);
  await fs.promises.mkdir(destDir, { recursive: true });
  await walk(zipPath, limits, { dest: destDir, prefix: info.prefix });
  return info;
}

module.exports = { LIMITS, BLOCKED_EXTENSIONS, ZipValidationError, scanZip, extractZip };
