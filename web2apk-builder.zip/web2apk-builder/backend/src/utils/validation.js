'use strict';

const fs = require('fs');
const { scanZip, ZipValidationError } = require('./safeZip');

class ValidationError extends Error {
  constructor(message, status = 400) {
    super(message);
    this.name = 'ValidationError';
    this.status = status;
    this.expose = true;
  }
}

const JAVA_KEYWORDS = new Set([
  'abstract', 'assert', 'boolean', 'break', 'byte', 'case', 'catch', 'char', 'class', 'const',
  'continue', 'default', 'do', 'double', 'else', 'enum', 'extends', 'final', 'finally', 'float',
  'for', 'goto', 'if', 'implements', 'import', 'instanceof', 'int', 'interface', 'long', 'native',
  'new', 'package', 'private', 'protected', 'public', 'return', 'short', 'static', 'strictfp',
  'super', 'switch', 'synchronized', 'this', 'throw', 'throws', 'transient', 'try', 'void',
  'volatile', 'while', 'true', 'false', 'null',
]);

const PACKAGE_RE = /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/;
// eslint-disable-next-line no-control-regex
const CONTROL_RE = /[\u0000-\u001F\u007F-\u009F\u2028\u2029\u202A-\u202E\u2066-\u2069]/g;

/** Returns the sanitized app name or throws a ValidationError. */
function validateAppName(input) {
  if (typeof input !== 'string') throw new ValidationError('App name is required');
  const name = input.replace(CONTROL_RE, ' ').replace(/[<>]/g, '').replace(/\s+/g, ' ').trim();
  const length = Array.from(name).length;
  if (length < 1 || length > 50) throw new ValidationError('App name must be between 1 and 50 characters');
  return name;
}

/** Returns the package name or throws a ValidationError. */
function validatePackageName(input) {
  if (typeof input !== 'string') throw new ValidationError('Package name is required');
  const value = input.trim();
  if (value.length > 150) throw new ValidationError('Package name is too long');
  if (!PACKAGE_RE.test(value)) {
    throw new ValidationError(
      'Package name must look like com.company.myapp: lowercase letters, digits and underscores, at least two dot-separated segments, each starting with a letter'
    );
  }
  for (const segment of value.split('.')) {
    if (JAVA_KEYWORDS.has(segment)) throw new ValidationError(`Package name segment "${segment}" is a reserved word`);
  }
  return value;
}

const PNG_SIGNATURE = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

async function readPngInfo(filePath, label) {
  const handle = await fs.promises.open(filePath, 'r');
  try {
    const { size } = await handle.stat();
    const head = Buffer.alloc(33);
    const { bytesRead } = await handle.read(head, 0, 33, 0);
    const tail = Buffer.alloc(12);
    if (size >= 12) await handle.read(tail, 0, 12, size - 12);
    const valid =
      bytesRead === 33 &&
      head.subarray(0, 8).equals(PNG_SIGNATURE) &&
      head.toString('ascii', 12, 16) === 'IHDR' &&
      tail.toString('ascii', 4, 8) === 'IEND';
    if (!valid) throw new ValidationError(`${label} must be a valid PNG image`);
    return { width: head.readUInt32BE(16), height: head.readUInt32BE(20), size };
  } finally {
    await handle.close();
  }
}

async function validateIcon(file, limits) {
  if (!file) throw new ValidationError('App icon (PNG) is required');
  if (file.size > limits.maxIconBytes) throw new ValidationError('App icon must be smaller than 2 MB');
  const info = await readPngInfo(file.path, 'App icon');
  if (info.width !== info.height) throw new ValidationError('App icon must be square');
  if (info.width < limits.iconMin || info.width > limits.iconMax) {
    throw new ValidationError(`App icon must be between ${limits.iconMin}x${limits.iconMin} and ${limits.iconMax}x${limits.iconMax} pixels`);
  }
  return info;
}

async function validateSplash(file, limits) {
  if (!file) return null;
  if (file.size > limits.maxSplashBytes) throw new ValidationError('Splash image must be smaller than 5 MB');
  const info = await readPngInfo(file.path, 'Splash image');
  const { splashMin: min, splashMax: max } = limits;
  if (info.width < min || info.height < min || info.width > max || info.height > max) {
    throw new ValidationError(`Splash image must be between ${min} and ${max} pixels on each side`);
  }
  return info;
}

async function validateWebsiteZip(file, limits) {
  if (!file) throw new ValidationError('Website ZIP is required');
  if (file.size > limits.maxZipBytes) throw new ValidationError('Website ZIP must be smaller than 20 MB');

  const handle = await fs.promises.open(file.path, 'r');
  const magic = Buffer.alloc(4);
  try {
    await handle.read(magic, 0, 4, 0);
  } finally {
    await handle.close();
  }
  if (!(magic[0] === 0x50 && magic[1] === 0x4b && magic[2] === 0x03 && magic[3] === 0x04)) {
    throw new ValidationError('The uploaded website file is not a ZIP archive');
  }

  try {
    return await scanZip(file.path, {
      maxFiles: limits.maxFiles,
      maxFileBytes: limits.maxFileBytes,
      maxTotalBytes: limits.maxTotalBytes,
    });
  } catch (err) {
    if (err instanceof ZipValidationError) throw new ValidationError(err.message);
    throw err;
  }
}

module.exports = {
  ValidationError,
  validateAppName,
  validatePackageName,
  validateIcon,
  validateSplash,
  validateWebsiteZip,
};
