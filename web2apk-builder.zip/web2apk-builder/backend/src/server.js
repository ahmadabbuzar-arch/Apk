'use strict';

const fs = require('fs');
const path = require('path');
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const multer = require('multer');

const config = require('./config');
const log = require('./utils/logger');
const { createDatabase } = require('./db/database');
const { createStorage } = require('./services/storage');
const { GithubClient } = require('./services/github');
const { BuildService } = require('./services/buildService');
const { createHealthRouter } = require('./routes/health');
const { createBuildsRouter } = require('./routes/builds');
const { createGithubRouter } = require('./routes/github');

function createApp({ config: cfg, buildService, storage }) {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', cfg.trustProxy);

  app.use(
    helmet({
      // The single-file frontend uses inline <style> and <script>.
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          scriptSrc: ["'self'", "'unsafe-inline'"],
          styleSrc: ["'self'", "'unsafe-inline'"],
          imgSrc: ["'self'", 'data:', 'blob:'],
          connectSrc: ["'self'"],
          objectSrc: ["'none'"],
          frameAncestors: ["'none'"],
          baseUri: ["'self'"],
          formAction: ["'self'"],
        },
      },
    })
  );
  app.use(
    cors({
      origin: cfg.corsOrigins === '*' ? true : cfg.corsOrigins,
      methods: ['GET', 'POST'],
      maxAge: 600,
    })
  );

  // The webhook needs the raw body, so it is mounted before express.json().
  app.use('/api/github', createGithubRouter({ config: cfg, buildService }));
  app.use(express.json({ limit: '100kb' }));

  app.use('/api/health', createHealthRouter({ config: cfg }));
  app.use('/api/builds', createBuildsRouter({ config: cfg, buildService, storage }));

  app.use('/api', (req, res) => res.status(404).json({ success: false, error: 'Not found' }));

  const indexFile = path.join(cfg.frontendDir, 'index.html');
  if (fs.existsSync(indexFile)) {
    app.get('/', (req, res) => res.sendFile(indexFile));
  }

  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    if (err instanceof multer.MulterError) {
      const tooBig = err.code === 'LIMIT_FILE_SIZE';
      return res.status(tooBig ? 413 : 400).json({
        success: false,
        error: tooBig ? 'File is too large (website ZIP: max 20 MB)' : 'Invalid upload',
      });
    }
    if (err && err.type === 'entity.too.large') {
      return res.status(413).json({ success: false, error: 'Request body is too large' });
    }
    if (err && err.type === 'entity.parse.failed') {
      return res.status(400).json({ success: false, error: 'Invalid JSON body' });
    }
    if (err && err.expose && err.status) {
      return res.status(err.status).json({ success: false, error: err.message });
    }
    log.error(`Unhandled error on ${req.method} ${req.path}`, err && err.stack ? err.stack : err);
    return res.status(500).json({ success: false, error: 'Internal server error' });
  });

  return app;
}

function main() {
  const db = createDatabase(config);
  const storage = createStorage(config);
  const github = new GithubClient(config);
  const buildService = new BuildService({ config, db, storage, github });
  const app = createApp({ config, buildService, storage });

  // Leftover temporary uploads from a previous run are never needed again.
  const tmpDir = path.join(config.storagePath, 'tmp');
  fs.rmSync(tmpDir, { recursive: true, force: true });
  fs.mkdirSync(tmpDir, { recursive: true });

  const server = app.listen(config.port, () => {
    log.info(`Web2APK backend listening on port ${config.port}`);
    if (!config.githubConfigured) log.warn('GitHub is not configured (GITHUB_TOKEN, GITHUB_OWNER, GITHUB_REPO): builds are disabled');
    if (!config.webhookSecret) log.warn('WEBHOOK_SECRET is not set: relying on polling only');
    buildService.start();
  });

  const shutdown = () => {
    log.info('Shutting down');
    buildService.stop();
    server.close(() => {
      db.close();
      process.exit(0);
    });
    setTimeout(() => process.exit(1), 10000).unref();
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

if (require.main === module) main();

module.exports = { createApp };
