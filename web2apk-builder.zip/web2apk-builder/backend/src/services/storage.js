'use strict';

/**
 * Storage abstraction.
 *
 * Every driver implements the same interface (all methods are async except
 * createReadStream):
 *
 *   putFile(key, filePath)            store a local file
 *   putBuffer(key, buffer)            store in-memory data
 *   createReadStream(key)             readable stream of the stored object
 *   stat(key)                         { size } or null when the object is missing
 *   delete(key)                       remove an object (missing keys are ignored)
 *   deletePrefix(prefix)              remove every object below a prefix
 *   getDownloadUrl(key, options)      a public/presigned URL, or null when the
 *                                     backend itself must stream the object
 *
 * To add S3-compatible storage or Supabase Storage, create a class with this
 * interface (getDownloadUrl returns a presigned URL there) and register it in
 * createStorage() below.
 *
 * Keys look like "builds/<buildId>/website.zip" or "apks/<buildId>/<slug>.apk".
 */

const fs = require('fs');
const path = require('path');

const KEY_RE = /^[A-Za-z0-9][A-Za-z0-9._\-/]*$/;

class LocalStorage {
  constructor(basePath) {
    this.base = path.resolve(basePath);
    fs.mkdirSync(this.base, { recursive: true });
  }

  resolveKey(key) {
    if (typeof key !== 'string' || !KEY_RE.test(key) || key.split('/').some((p) => p === '..' || p === '.' || p === '')) {
      throw new Error('Invalid storage key');
    }
    const resolved = path.resolve(this.base, key);
    if (!resolved.startsWith(this.base + path.sep)) throw new Error('Invalid storage key');
    return resolved;
  }

  async putFile(key, filePath) {
    const dest = this.resolveKey(key);
    await fs.promises.mkdir(path.dirname(dest), { recursive: true });
    await fs.promises.copyFile(filePath, dest);
  }

  async putBuffer(key, buffer) {
    const dest = this.resolveKey(key);
    await fs.promises.mkdir(path.dirname(dest), { recursive: true });
    await fs.promises.writeFile(dest, buffer);
  }

  createReadStream(key) {
    return fs.createReadStream(this.resolveKey(key));
  }

  async stat(key) {
    try {
      const st = await fs.promises.stat(this.resolveKey(key));
      return st.isFile() ? { size: st.size } : null;
    } catch (err) {
      if (err.code === 'ENOENT') return null;
      throw err;
    }
  }

  async delete(key) {
    await fs.promises.rm(this.resolveKey(key), { force: true });
  }

  async deletePrefix(prefix) {
    await fs.promises.rm(this.resolveKey(prefix.replace(/\/+$/, '')), { recursive: true, force: true });
  }

  // eslint-disable-next-line no-unused-vars
  async getDownloadUrl(key, options) {
    return null; // the backend streams local files itself
  }
}

function createStorage(config) {
  switch (config.storageDriver) {
    case 'local':
      return new LocalStorage(config.storagePath);
    default:
      throw new Error(`Unsupported STORAGE_DRIVER "${config.storageDriver}". Available drivers: local`);
  }
}

module.exports = { createStorage, LocalStorage };
