'use strict';

const yauzl = require('yauzl');

const API_BASE = 'https://api.github.com';

class GithubError extends Error {
  constructor(message, status) {
    super(message);
    this.name = 'GithubError';
    this.status = status;
  }
}

/** Reads one file out of an in-memory ZIP (used for workflow artifacts). */
function readFileFromZipBuffer(buffer, matcher, maxBytes) {
  return new Promise((resolve, reject) => {
    yauzl.fromBuffer(buffer, { lazyEntries: true }, (err, zip) => {
      if (err) return reject(err);
      zip.on('error', reject);
      zip.on('end', () => resolve(null));
      zip.on('entry', (entry) => {
        if (entry.fileName.endsWith('/') || !matcher(entry.fileName)) return zip.readEntry();
        if (entry.uncompressedSize > maxBytes) {
          zip.close();
          return reject(new Error('Artifact file is too large'));
        }
        zip.openReadStream(entry, (streamErr, stream) => {
          if (streamErr) {
            zip.close();
            return reject(streamErr);
          }
          const chunks = [];
          let size = 0;
          stream.on('data', (chunk) => {
            size += chunk.length;
            if (size > maxBytes) stream.destroy(new Error('Artifact file is too large'));
            else chunks.push(chunk);
          });
          stream.on('error', (e) => {
            zip.close();
            reject(e);
          });
          stream.on('end', () => {
            zip.close();
            resolve({ name: entry.fileName, data: Buffer.concat(chunks) });
          });
        });
      });
      zip.readEntry();
    });
  });
}

class GithubClient {
  constructor(config) {
    this.config = config;
  }

  isConfigured() {
    return this.config.githubConfigured;
  }

  repoPath(suffix) {
    return `/repos/${this.config.githubOwner}/${this.config.githubRepo}${suffix}`;
  }

  async request(method, apiPath, { body, query, expect = [200] } = {}) {
    if (!this.isConfigured()) throw new GithubError('GitHub is not configured', 503);
    const url = new URL(API_BASE + apiPath);
    for (const [k, v] of Object.entries(query || {})) url.searchParams.set(k, String(v));

    const headers = {
      Authorization: `Bearer ${this.config.githubToken}`,
      Accept: 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28',
      'User-Agent': 'web2apk-builder',
    };
    if (body !== undefined) headers['Content-Type'] = 'application/json';

    const res = await fetch(url, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
      redirect: 'manual',
      signal: AbortSignal.timeout(30000),
    });

    if (!expect.includes(res.status)) {
      let detail = '';
      try {
        detail = (await res.json()).message || '';
      } catch (_) { /* no JSON body */ }
      throw new GithubError(`GitHub API ${method} ${apiPath} failed with ${res.status}${detail ? `: ${detail}` : ''}`, res.status);
    }
    return res;
  }

  async dispatchWorkflow(inputs) {
    await this.request(
      'POST',
      this.repoPath(`/actions/workflows/${encodeURIComponent(this.config.githubWorkflow)}/dispatches`),
      { body: { ref: this.config.githubRef, inputs }, expect: [204] }
    );
  }

  /** Finds the workflow run whose run-name contains the build id and that started after `since`. */
  async findRun(buildId, since) {
    const sinceMs = since ? Date.parse(since) - 120000 : 0;
    const res = await this.request(
      'GET',
      this.repoPath(`/actions/workflows/${encodeURIComponent(this.config.githubWorkflow)}/runs`),
      { query: { event: 'workflow_dispatch', per_page: 50 } }
    );
    const data = await res.json();
    return (
      (data.workflow_runs || []).find(
        (run) =>
          typeof run.display_title === 'string' &&
          run.display_title.includes(buildId) &&
          Date.parse(run.created_at) >= sinceMs
      ) || null
    );
  }

  async getRun(runId) {
    const res = await this.request('GET', this.repoPath(`/actions/runs/${Number(runId)}`));
    return res.json();
  }

  async getJobs(runId) {
    const res = await this.request('GET', this.repoPath(`/actions/runs/${Number(runId)}/jobs`), { query: { per_page: 10 } });
    return (await res.json()).jobs || [];
  }

  async cancelRun(runId) {
    // 202 = cancellation requested, 409 = run already finished
    await this.request('POST', this.repoPath(`/actions/runs/${Number(runId)}/cancel`), { expect: [202, 409] });
  }

  async listArtifacts(runId) {
    const res = await this.request('GET', this.repoPath(`/actions/runs/${Number(runId)}/artifacts`), { query: { per_page: 100 } });
    return (await res.json()).artifacts || [];
  }

  /** Downloads an artifact ZIP. The signed redirect target is fetched WITHOUT the GitHub token. */
  async downloadArtifact(artifactId, maxBytes) {
    const res = await this.request('GET', this.repoPath(`/actions/artifacts/${Number(artifactId)}/zip`), { expect: [200, 302] });
    let data = res;
    if (res.status === 302) {
      const location = res.headers.get('location');
      if (!location || !location.startsWith('https://')) throw new GithubError('Artifact download redirect was invalid', 502);
      data = await fetch(location, { signal: AbortSignal.timeout(5 * 60 * 1000) });
      if (!data.ok) throw new GithubError(`Artifact download failed with ${data.status}`, data.status);
    }
    const declared = Number(data.headers.get('content-length') || 0);
    if (declared > maxBytes) throw new GithubError('Artifact is too large', 502);
    const buffer = Buffer.from(await data.arrayBuffer());
    if (buffer.length > maxBytes) throw new GithubError('Artifact is too large', 502);
    return buffer;
  }
}

module.exports = { GithubClient, GithubError, readFileFromZipBuffer };
