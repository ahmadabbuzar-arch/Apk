'use strict';

const log = require('../utils/logger');
const { generateBuildId, generateToken, slugify } = require('../utils/security');
const {
  ValidationError,
  validateAppName,
  validatePackageName,
  validateIcon,
  validateSplash,
  validateWebsiteZip,
} = require('../utils/validation');
const { readFileFromZipBuffer } = require('./github');

const TERMINAL = new Set(['completed', 'failed', 'cancelled']);
const RUN_NAME_RE = /Web2APK build ([a-f0-9]{32})/;
const APK_CONTENT_TYPE = 'application/vnd.android.package-archive';

// Workflow step name prefix -> user visible stage (see .github/workflows/build-apk.yml)
const STEP_STAGES = [
  ['Prepare', 'preparing'],
  ['Build', 'building'],
  ['Sign', 'signing'],
  ['Upload', 'uploading'],
  ['Report', 'uploading'],
];

const FAILURE_MESSAGES = [
  ['Prepare', 'The website could not be prepared for the Android build.'],
  ['Build', 'The Android build failed.'],
  ['Sign', 'The APK could not be signed or verified.'],
  ['Upload', 'The finished APK could not be uploaded by the build runner.'],
];

function sanitizeMessage(text) {
  // eslint-disable-next-line no-control-regex
  return String(text).replace(/[\u0000-\u001F\u007F-\u009F]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 500);
}

function stageFromJobs(jobs) {
  let stage = 'preparing';
  for (const job of jobs) {
    for (const step of job.steps || []) {
      if (step.status === 'queued') continue;
      const match = STEP_STAGES.find(([prefix]) => step.name.startsWith(prefix));
      if (match) stage = match[1];
    }
  }
  return stage;
}

function failureFromJobs(jobs) {
  for (const job of jobs) {
    const failed = (job.steps || []).find((step) => step.conclusion === 'failure');
    if (failed) {
      const match = FAILURE_MESSAGES.find(([prefix]) => failed.name.startsWith(prefix));
      if (match) return match[1];
    }
  }
  return null;
}

class BuildService {
  constructor({ config, db, storage, github }) {
    this.config = config;
    this.db = db;
    this.storage = storage;
    this.github = github;
    this.queueChain = Promise.resolve();
    this.finalizing = new Set();
    this.reconciling = false;
    this.timer = null;
  }

  // ------------------------------------------------------------------ lifecycle

  start() {
    this.processQueue();
    this.timer = setInterval(() => {
      this.reconcile().catch((err) => log.error('Reconcile failed', err.message));
    }, this.config.reconcileIntervalSeconds * 1000);
    this.timer.unref();
  }

  stop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  // ------------------------------------------------------------------ public API

  async createBuild({ appName, packageName, website, icon, splash }) {
    if (!this.github.isConfigured()) {
      throw new ValidationError('The build service is not configured yet. Please contact the administrator.', 503);
    }
    const name = validateAppName(appName);
    const pkg = validatePackageName(packageName);
    const limits = this.config.limits;
    await validateWebsiteZip(website, limits);
    await validateIcon(icon, limits);
    await validateSplash(splash, limits);

    const id = generateBuildId();
    const createdAt = new Date().toISOString();
    const prefix = `builds/${id}`;

    try {
      await this.storage.putFile(`${prefix}/website.zip`, website.path);
      await this.storage.putFile(`${prefix}/icon.png`, icon.path);
      if (splash) await this.storage.putFile(`${prefix}/splash.png`, splash.path);
      const buildConfig = { buildId: id, appName: name, packageName: pkg, createdAt, hasSplash: Boolean(splash) };
      await this.storage.putBuffer(`${prefix}/config.json`, Buffer.from(`${JSON.stringify(buildConfig, null, 2)}\n`));
      await this.db.insertBuild({ id, appName: name, packageName: pkg, createdAt, inputToken: generateToken(), hasSplash: Boolean(splash) });
    } catch (err) {
      await this.storage.deletePrefix(prefix).catch(() => {});
      throw err;
    }

    log.info(`Build ${id} queued (${pkg})`);
    this.processQueue();
    return { id, status: 'queued' };
  }

  async getPublicBuild(id) {
    const build = await this.db.getBuild(id);
    if (!build) return null;
    return this.toPublic(build);
  }

  async toPublic(build) {
    return {
      id: build.id,
      appName: build.appName,
      packageName: build.packageName,
      status: build.status,
      stage: build.stage,
      createdAt: build.createdAt,
      startedAt: build.startedAt,
      completedAt: build.completedAt,
      apkUrl: build.status === 'completed' ? build.apkUrl : null,
      errorMessage: build.errorMessage,
      queuePosition: build.status === 'queued' ? await this.db.queuePosition(build) : 0,
    };
  }

  async cancelBuild(id) {
    const build = await this.db.getBuild(id);
    if (!build) throw new ValidationError('Build not found', 404);
    if (TERMINAL.has(build.status)) throw new ValidationError(`Build is already ${build.status}`, 409);

    let runId = build.githubRunId;
    if (build.status === 'building' && !runId) {
      try {
        const run = await this.github.findRun(id, build.startedAt);
        runId = run ? run.id : null;
      } catch (err) {
        log.warn(`Could not look up workflow run for build ${id}`, err.message);
      }
    }

    await this.markCancelled(id, 'The build was cancelled.');
    if (runId) {
      try {
        await this.github.cancelRun(runId);
      } catch (err) {
        log.warn(`Could not cancel workflow run ${runId}`, err.message);
      }
    }
    return this.getPublicBuild(id);
  }

  async retryBuild(id) {
    const build = await this.db.getBuild(id);
    if (!build) throw new ValidationError('Build not found', 404);
    if (build.status !== 'failed' && build.status !== 'cancelled') {
      throw new ValidationError('Only failed or cancelled builds can be retried', 409);
    }
    const [website, icon] = await Promise.all([
      this.storage.stat(`builds/${id}/website.zip`),
      this.storage.stat(`builds/${id}/icon.png`),
    ]);
    if (!website || !icon) {
      throw new ValidationError('The uploaded files for this build are no longer available. Please create a new build.', 410);
    }

    await this.db.updateBuild(id, {
      status: 'queued',
      stage: 'queued',
      queuedAt: new Date().toISOString(),
      startedAt: null,
      completedAt: null,
      errorMessage: null,
      githubRunId: null,
      inputToken: generateToken(),
      apkUrl: null,
      apkKey: null,
      apkSize: null,
      attempts: build.attempts + 1,
    });
    log.info(`Build ${id} re-queued`);
    this.processQueue();
    return this.getPublicBuild(id);
  }

  /** Called by the signed GitHub webhook (workflow_run event). */
  async handleWorkflowRun(run) {
    const match = RUN_NAME_RE.exec(run.display_title || '');
    if (!match) return;
    const build = await this.db.getBuild(match[1]);
    if (!build) return;
    await this.processRun(build, run);
  }

  // ------------------------------------------------------------------ queue

  processQueue() {
    this.queueChain = this.queueChain
      .then(() => this.runQueue())
      .catch((err) => log.error('Queue processing failed', err.message));
    return this.queueChain;
  }

  async runQueue() {
    const running = await this.db.countByStatus('building');
    const slots = this.config.maxConcurrentBuilds - running;
    if (slots <= 0) return;
    for (const build of await this.db.listQueued(slots)) {
      await this.startBuild(build);
    }
  }

  async startBuild(queued) {
    const claimed = await this.db.claimQueued(queued.id, new Date().toISOString());
    if (!claimed) return;
    const build = await this.db.getBuild(queued.id);
    try {
      await this.github.dispatchWorkflow({
        build_id: build.id,
        app_name: build.appName,
        package_name: build.packageName,
        backend_url: this.config.publicBaseUrl,
        input_token: build.inputToken,
        has_splash: String(build.hasSplash),
      });
      log.info(`Build ${build.id} dispatched to GitHub Actions`);
    } catch (err) {
      log.error(`Could not dispatch build ${build.id}`, err.message);
      await this.markFailed(build.id, 'The build could not be started. Please try again in a few minutes.');
    }
  }

  // ------------------------------------------------------------------ state changes

  async markFailed(id, message) {
    const build = await this.db.getBuild(id);
    if (!build || TERMINAL.has(build.status)) return;
    await this.db.updateBuild(id, {
      status: 'failed',
      stage: 'failed',
      completedAt: new Date().toISOString(),
      errorMessage: sanitizeMessage(message),
      inputToken: null,
    });
    log.warn(`Build ${id} failed: ${message}`);
    this.processQueue();
  }

  async markCancelled(id, message) {
    const build = await this.db.getBuild(id);
    if (!build || TERMINAL.has(build.status)) return;
    await this.db.updateBuild(id, {
      status: 'cancelled',
      stage: 'cancelled',
      completedAt: new Date().toISOString(),
      errorMessage: message,
      inputToken: null,
    });
    log.info(`Build ${id} cancelled`);
    this.processQueue();
  }

  runBelongsToAttempt(build, run) {
    if (build.githubRunId) return build.githubRunId === run.id;
    const created = Date.parse(run.created_at);
    const started = Date.parse(build.startedAt);
    return Number.isFinite(created) && Number.isFinite(started) && created >= started - 120000;
  }

  async processRun(build, run) {
    if (build.status !== 'building') return;
    if (!this.runBelongsToAttempt(build, run)) return;
    if (!build.githubRunId) await this.db.updateBuild(build.id, { githubRunId: run.id });
    if (run.status !== 'completed') return;

    if (run.conclusion === 'success') {
      await this.finalizeSuccess(build.id, run);
    } else if (run.conclusion === 'cancelled') {
      await this.markCancelled(build.id, 'The build was cancelled.');
    } else {
      await this.markFailed(build.id, await this.describeFailure(build, run));
    }
  }

  async finalizeSuccess(id, run) {
    if (this.finalizing.has(id)) return;
    this.finalizing.add(id);
    try {
      const build = await this.db.getBuild(id);
      if (!build || build.status !== 'building') return;
      await this.db.updateBuild(id, { stage: 'uploading' });

      const artifacts = await this.github.listArtifacts(run.id);
      const artifact = artifacts.find((a) => a.name === `apk-${id}` && !a.expired);
      if (!artifact) throw new Error('APK artifact not found on the workflow run');

      const zipBuffer = await this.github.downloadArtifact(artifact.id, this.config.limits.maxApkBytes);
      const file = await readFileFromZipBuffer(zipBuffer, (n) => n.toLowerCase().endsWith('.apk'), this.config.limits.maxApkBytes);
      if (!file || file.data.length < 1024 || file.data[0] !== 0x50 || file.data[1] !== 0x4b) {
        throw new Error('The artifact does not contain a valid APK');
      }

      const key = `apks/${id}/${slugify(build.appName)}.apk`;
      await this.storage.putBuffer(key, file.data);
      const apkUrl = `${this.config.publicBaseUrl}/api/builds/${id}/download`;

      await this.db.updateBuild(id, {
        status: 'completed',
        stage: 'completed',
        completedAt: new Date().toISOString(),
        apkUrl,
        apkKey: key,
        apkSize: file.data.length,
        errorMessage: null,
        inputToken: null,
      });
      log.info(`Build ${id} completed (${file.data.length} bytes)`);

      // The inputs are no longer needed once the APK exists.
      for (const name of ['website.zip', 'icon.png', 'splash.png']) {
        await this.storage.delete(`builds/${id}/${name}`).catch(() => {});
      }
      this.processQueue();
    } catch (err) {
      log.error(`Could not retrieve APK for build ${id}`, err.message);
      await this.markFailed(id, 'The APK was built but could not be retrieved. Please retry the build.');
    } finally {
      this.finalizing.delete(id);
    }
  }

  async describeFailure(build, run) {
    try {
      const artifacts = await this.github.listArtifacts(run.id);
      const artifact = artifacts.find((a) => a.name === `error-${build.id}` && !a.expired);
      if (artifact) {
        const zipBuffer = await this.github.downloadArtifact(artifact.id, 1024 * 1024);
        const file = await readFileFromZipBuffer(zipBuffer, (n) => n === 'error.txt', 16 * 1024);
        const text = file ? sanitizeMessage(file.data.toString('utf8')) : '';
        if (text) return text;
      }
    } catch (err) {
      log.warn(`Could not read error report for build ${build.id}`, err.message);
    }
    try {
      const message = failureFromJobs(await this.github.getJobs(run.id));
      if (message) return message;
    } catch (err) {
      log.warn(`Could not read jobs for build ${build.id}`, err.message);
    }
    return 'The build failed. Please try again.';
  }

  // ------------------------------------------------------------------ reconciliation

  /** Safety net: syncs running builds with GitHub even if a webhook was missed. */
  async reconcile() {
    if (this.reconciling) return;
    this.reconciling = true;
    try {
      for (const build of await this.db.listByStatus('building')) {
        try {
          await this.reconcileOne(build);
        } catch (err) {
          log.warn(`Reconcile of build ${build.id} failed`, err.message);
        }
      }
    } finally {
      this.reconciling = false;
    }
  }

  async reconcileOne(build) {
    let run = null;
    if (build.githubRunId) {
      run = await this.github.getRun(build.githubRunId);
    } else {
      run = await this.github.findRun(build.id, build.startedAt);
      if (run) await this.db.updateBuild(build.id, { githubRunId: run.id });
    }

    if (run && run.status === 'completed') {
      await this.processRun({ ...build, githubRunId: run.id }, run);
      return;
    }

    if (run) {
      const stage = stageFromJobs(await this.github.getJobs(run.id));
      if (stage !== build.stage) await this.db.updateBuild(build.id, { stage });
    }

    const elapsed = Date.now() - Date.parse(build.startedAt);
    if (elapsed > this.config.buildTimeoutMinutes * 60 * 1000) {
      if (run) await this.github.cancelRun(run.id).catch(() => {});
      await this.markFailed(build.id, 'The build took too long and was stopped. Please try again.');
    }
  }
}

module.exports = { BuildService, APK_CONTENT_TYPE, TERMINAL };
