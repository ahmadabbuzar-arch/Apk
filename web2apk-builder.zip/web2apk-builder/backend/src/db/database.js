'use strict';

/**
 * SQLite persistence layer (better-sqlite3).
 *
 * The rest of the application only uses the repository object returned by
 * createDatabase(). To move to PostgreSQL/Supabase later, write another module
 * that returns an object with the same methods (all of them can be made async
 * and are already awaited by BuildService) and switch on a DATABASE_DRIVER
 * setting here.
 */

const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

// camelCase API field -> SQL column. Only these columns can ever be written.
const COLUMNS = Object.freeze({
  appName: 'app_name',
  packageName: 'package_name',
  status: 'status',
  stage: 'stage',
  createdAt: 'created_at',
  queuedAt: 'queued_at',
  startedAt: 'started_at',
  completedAt: 'completed_at',
  apkUrl: 'apk_url',
  apkKey: 'apk_key',
  apkSize: 'apk_size',
  errorMessage: 'error_message',
  githubRunId: 'github_run_id',
  inputToken: 'input_token',
  attempts: 'attempts',
  hasSplash: 'has_splash',
});

const SCHEMA = `
  CREATE TABLE IF NOT EXISTS builds (
    id            TEXT PRIMARY KEY,
    app_name      TEXT NOT NULL,
    package_name  TEXT NOT NULL,
    status        TEXT NOT NULL CHECK (status IN ('queued','building','completed','failed','cancelled')),
    stage         TEXT NOT NULL DEFAULT 'queued',
    created_at    TEXT NOT NULL,
    queued_at     TEXT NOT NULL,
    started_at    TEXT,
    completed_at  TEXT,
    apk_url       TEXT,
    apk_key       TEXT,
    apk_size      INTEGER,
    error_message TEXT,
    github_run_id INTEGER,
    input_token   TEXT,
    attempts      INTEGER NOT NULL DEFAULT 0,
    has_splash    INTEGER NOT NULL DEFAULT 0
  );
  CREATE INDEX IF NOT EXISTS idx_builds_status_queued ON builds (status, queued_at);
`;

function rowToBuild(row) {
  if (!row) return null;
  return {
    id: row.id,
    appName: row.app_name,
    packageName: row.package_name,
    status: row.status,
    stage: row.stage,
    createdAt: row.created_at,
    queuedAt: row.queued_at,
    startedAt: row.started_at,
    completedAt: row.completed_at,
    apkUrl: row.apk_url,
    apkKey: row.apk_key,
    apkSize: row.apk_size,
    errorMessage: row.error_message,
    githubRunId: row.github_run_id,
    inputToken: row.input_token,
    attempts: row.attempts,
    hasSplash: Boolean(row.has_splash),
  };
}

function createDatabase(config) {
  fs.mkdirSync(path.dirname(config.databasePath), { recursive: true });
  const db = new Database(config.databasePath);
  db.pragma('journal_mode = WAL');
  db.pragma('busy_timeout = 5000');
  db.exec(SCHEMA);

  const stmts = {
    insert: db.prepare(`
      INSERT INTO builds (id, app_name, package_name, status, stage, created_at, queued_at, input_token, has_splash)
      VALUES (@id, @appName, @packageName, 'queued', 'queued', @createdAt, @createdAt, @inputToken, @hasSplash)
    `),
    get: db.prepare('SELECT * FROM builds WHERE id = ?'),
    claim: db.prepare(`
      UPDATE builds SET status = 'building', stage = 'preparing', started_at = ?, completed_at = NULL, error_message = NULL
      WHERE id = ? AND status = 'queued'
    `),
    countByStatus: db.prepare('SELECT COUNT(*) AS n FROM builds WHERE status = ?'),
    listQueued: db.prepare("SELECT * FROM builds WHERE status = 'queued' ORDER BY queued_at ASC, rowid ASC LIMIT ?"),
    listByStatus: db.prepare('SELECT * FROM builds WHERE status = ? ORDER BY queued_at ASC, rowid ASC'),
    queuePosition: db.prepare(`
      SELECT COUNT(*) AS n FROM builds
      WHERE status = 'queued' AND (queued_at < @queuedAt OR (queued_at = @queuedAt AND rowid <= (SELECT rowid FROM builds WHERE id = @id)))
    `),
  };

  return {
    insertBuild(build) {
      stmts.insert.run({ ...build, hasSplash: build.hasSplash ? 1 : 0 });
      return rowToBuild(stmts.get.get(build.id));
    },

    getBuild(id) {
      return rowToBuild(stmts.get.get(id));
    },

    updateBuild(id, patch) {
      const sets = [];
      const values = { id };
      for (const [key, value] of Object.entries(patch)) {
        const column = COLUMNS[key];
        if (!column) throw new Error(`Unknown build field: ${key}`);
        sets.push(`${column} = @${key}`);
        values[key] = key === 'hasSplash' ? (value ? 1 : 0) : value;
      }
      if (sets.length === 0) return rowToBuild(stmts.get.get(id));
      db.prepare(`UPDATE builds SET ${sets.join(', ')} WHERE id = @id`).run(values);
      return rowToBuild(stmts.get.get(id));
    },

    /** Atomically moves a build from queued to building. Returns false if someone else got it. */
    claimQueued(id, startedAt) {
      return stmts.claim.run(startedAt, id).changes === 1;
    },

    countByStatus(status) {
      return stmts.countByStatus.get(status).n;
    },

    listQueued(limit) {
      return stmts.listQueued.all(limit).map(rowToBuild);
    },

    listByStatus(status) {
      return stmts.listByStatus.all(status).map(rowToBuild);
    },

    /** 1-based position in the queue (0 if the build is not queued). */
    queuePosition(build) {
      if (build.status !== 'queued') return 0;
      return stmts.queuePosition.get({ id: build.id, queuedAt: build.queuedAt }).n;
    },

    close() {
      db.close();
    },
  };
}

module.exports = { createDatabase };
