'use strict';

const path = require('path');
const dotenv = require('dotenv');

const backendRoot = path.resolve(__dirname, '..');
dotenv.config({ path: path.join(backendRoot, '.env') });

function str(name, fallback = '') {
  const value = process.env[name];
  return value === undefined || value.trim() === '' ? fallback : value.trim();
}

function int(name, fallback, { min = 0, max = Number.MAX_SAFE_INTEGER } = {}) {
  const raw = process.env[name];
  if (raw === undefined || raw.trim() === '') return fallback;
  const value = Number.parseInt(raw, 10);
  if (!Number.isInteger(value) || value < min || value > max) {
    throw new Error(`Invalid value for ${name}: expected an integer between ${min} and ${max}`);
  }
  return value;
}

function resolvePath(value) {
  return path.isAbsolute(value) ? value : path.resolve(backendRoot, value);
}

const port = int('PORT', 3000, { min: 1, max: 65535 });
const githubOwner = str('GITHUB_OWNER');
const githubRepo = str('GITHUB_REPO');
const githubWorkflow = str('GITHUB_WORKFLOW', 'build-apk.yml');
const githubToken = str('GITHUB_TOKEN');

if (githubOwner && !/^[A-Za-z0-9_.-]+$/.test(githubOwner)) {
  throw new Error('GITHUB_OWNER contains invalid characters');
}
if (githubRepo && !/^[A-Za-z0-9_.-]+$/.test(githubRepo)) {
  throw new Error('GITHUB_REPO contains invalid characters');
}
if (!/^[A-Za-z0-9_.-]+\.ya?ml$/.test(githubWorkflow)) {
  throw new Error('GITHUB_WORKFLOW must be a workflow file name such as build-apk.yml');
}

const corsRaw = str('CORS_ORIGIN', '*');
const trustProxyRaw = str('TRUST_PROXY', '0');

const config = Object.freeze({
  env: str('NODE_ENV', 'development'),
  port,
  publicBaseUrl: str('PUBLIC_BASE_URL', `http://localhost:${port}`).replace(/\/+$/, ''),

  githubToken,
  githubOwner,
  githubRepo,
  githubWorkflow,
  githubRef: str('GITHUB_REF', 'main'),
  githubConfigured: Boolean(githubToken && githubOwner && githubRepo),

  storageDriver: str('STORAGE_DRIVER', 'local'),
  storagePath: resolvePath(str('STORAGE_PATH', './uploads')),
  databasePath: resolvePath(str('DATABASE_PATH', './data/database.sqlite')),
  frontendDir: resolvePath(str('FRONTEND_DIR', '../frontend')),

  maxConcurrentBuilds: int('MAX_CONCURRENT_BUILDS', 2, { min: 1, max: 20 }),
  buildTimeoutMinutes: int('BUILD_TIMEOUT_MINUTES', 30, { min: 5, max: 360 }),
  reconcileIntervalSeconds: int('RECONCILE_INTERVAL_SECONDS', 15, { min: 5, max: 600 }),
  buildRateLimitPerHour: int('BUILD_RATE_LIMIT_PER_HOUR', 10, { min: 1, max: 10000 }),

  webhookSecret: str('WEBHOOK_SECRET'),
  corsOrigins: corsRaw === '*' ? '*' : corsRaw.split(',').map((s) => s.trim()).filter(Boolean),
  trustProxy: /^\d+$/.test(trustProxyRaw) ? Number(trustProxyRaw) : trustProxyRaw,

  limits: Object.freeze({
    maxZipBytes: 20 * 1024 * 1024,
    maxIconBytes: 2 * 1024 * 1024,
    maxSplashBytes: 5 * 1024 * 1024,
    maxFiles: 1000,
    maxFileBytes: 10 * 1024 * 1024,
    maxTotalBytes: 200 * 1024 * 1024,
    maxApkBytes: 100 * 1024 * 1024,
    iconMin: 192,
    iconMax: 1024,
    splashMin: 200,
    splashMax: 4096,
  }),
});

module.exports = config;
