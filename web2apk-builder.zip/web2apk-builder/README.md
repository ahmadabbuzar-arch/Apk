# Web2APK Builder

Upload a website ZIP, get a signed Android APK. The APK is compiled on **GitHub Actions** (never on your backend).

```
Browser (frontend/index.html) -> Node.js API (SQLite + storage) -> GitHub Actions (JDK 17, Android SDK, Gradle)
   -> Android WebView app with your site in assets -> signed APK -> storage -> download link
```

## 1. Requirements

- Node.js 20 or newer (22 recommended) and npm
- A GitHub account and a repository that contains this project
- `keytool` (ships with any JDK) to create the signing key
- A way for GitHub to reach your backend (public server, or a tunnel such as `cloudflared tunnel` / `ngrok` during development)

## 2. Project structure

```
frontend/index.html          single-file UI (HTML + CSS + JS)
backend/src/                 Express API, queue, SQLite, storage, GitHub client
backend/test/                node:test unit tests
android-template/            Kotlin WebView app (site is injected into app/src/main/assets/site/)
scripts/                     validate-site.js, prepare-build.js, inject-config.js (run by the workflow)
.github/workflows/build-apk.yml
examples/sample-site/        single-file sample website
```

Note: `backend/src/utils/safeZip.js` and `scripts/lib/safeZip.js` are intentionally identical copies (the backend and the workflow each need it). Keep them in sync.

## 3. Local installation

```bash
git clone <your repo> web2apk-builder && cd web2apk-builder
cd backend && npm install
cp .env.example .env        # then edit .env
cd ../scripts && npm install   # only needed to run the scripts locally
```

## 4. Backend installation

`better-sqlite3` is a native module; prebuilt binaries exist for current Node versions. If installation falls back to compiling, install a C++ toolchain (`build-essential` / Xcode CLT).

## 5. Environment variables (`backend/.env`)

| Variable | Meaning |
|---|---|
| `PORT` | HTTP port (3000) |
| `PUBLIC_BASE_URL` | Public URL of this backend. GitHub Actions downloads the uploaded files from it, so it must be reachable from the internet |
| `GITHUB_TOKEN` | Fine-grained token (see section 8) |
| `GITHUB_OWNER`, `GITHUB_REPO` | Repository that holds the workflow |
| `GITHUB_WORKFLOW` | Workflow file name (`build-apk.yml`) |
| `GITHUB_REF` | Branch containing the workflow (`main`) |
| `STORAGE_PATH` | Local storage folder (`./uploads`) |
| `DATABASE_PATH` | SQLite file (`./data/database.sqlite`) |
| `MAX_CONCURRENT_BUILDS` | Builds running at once (2); the rest stay `queued` |
| `WEBHOOK_SECRET` | Shared secret for the GitHub webhook |
| `CORS_ORIGIN`, `TRUST_PROXY`, `BUILD_TIMEOUT_MINUTES`, `RECONCILE_INTERVAL_SECONDS`, `BUILD_RATE_LIMIT_PER_HOUR`, `FRONTEND_DIR` | Optional tuning, see `.env.example` |

Generate a webhook secret: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`

## 6. GitHub repository setup

1. Create a **private** repository and push this whole project (the workflow needs `android-template/` and `scripts/`).
2. Make sure the workflow is on the branch named in `GITHUB_REF`.

## 7. GitHub Actions setup

The workflow `.github/workflows/build-apk.yml` has only a `workflow_dispatch` trigger, so only the API (or someone with write access) can start it. It: checks out the repo, installs JDK 17, Android SDK and Gradle 8.7, downloads the build inputs from the backend with a one-time token, validates and extracts the ZIP into `android-template/app/src/main/assets/site/`, injects app name / package / icons, restores the keystore, runs `gradle assembleRelease`, verifies the signature with `apksigner`, uploads the APK as artifact `apk-<buildId>`, and removes the keystore.

Add the **webhook** (recommended; polling every 15 s is the fallback): Repository > Settings > Webhooks > Add webhook
- Payload URL: `https://YOUR_BACKEND/api/github/webhook`
- Content type: `application/json`
- Secret: the value of `WEBHOOK_SECRET`
- Events: *Workflow runs* only

## 8. GitHub token creation

Settings > Developer settings > Personal access tokens > **Fine-grained tokens** > Generate:
- Repository access: only your Web2APK repository
- Permissions: **Actions: Read and write**, **Contents: Read**, **Metadata: Read**

Put it in `GITHUB_TOKEN`. It stays on the server and is never sent to the browser.

## 9-11. Signing key and GitHub Secrets

```bash
keytool -genkeypair -v -keystore release.jks -alias web2apk -keyalg RSA -keysize 2048 -validity 10000
# Linux:  base64 -w 0 release.jks > keystore.base64
# macOS:  base64 -i release.jks | tr -d '\n' > keystore.base64
# Windows PowerShell: [Convert]::ToBase64String([IO.File]::ReadAllBytes("release.jks")) > keystore.base64
```

Repository > Settings > Secrets and variables > Actions > New repository secret:

| Secret | Value |
|---|---|
| `ANDROID_KEYSTORE_BASE64` | contents of `keystore.base64` |
| `ANDROID_KEYSTORE_PASSWORD` | keystore password |
| `ANDROID_KEY_ALIAS` | `web2apk` (the alias you chose) |
| `ANDROID_KEY_PASSWORD` | key password |

**Back up `release.jks` somewhere safe and never commit it** (`*.jks`/`*.keystore` are in `.gitignore`). All apps built by this service share this key; if you lose it, users cannot update installed apps.

## 12. Running the backend

```bash
cd backend && npm start        # or: npm run dev
curl http://localhost:3000/api/health
```

## 13. Running the frontend

The backend serves `frontend/index.html` at `http://localhost:3000/`. To host it elsewhere, set `API_BASE` at the top of its script and add the page origin to `CORS_ORIGIN`.

## 14. Testing the API

```bash
node scripts/make-test-assets.js      # creates examples/sample-site.zip, test-icon.png, test-splash.png
curl -F website=@examples/sample-site.zip -F appName="Sample" -F packageName=com.example.sample \
     -F icon=@examples/test-icon.png http://localhost:3000/api/builds
curl http://localhost:3000/api/builds/<buildId>
curl -OJ http://localhost:3000/api/builds/<buildId>/download      # when completed
curl -X POST http://localhost:3000/api/builds/<buildId>/cancel    # or /retry
cd backend && npm test
```

Error examples: a ZIP without `index.html` returns `{"success":false,"error":"index.html not found"}`.

## 15. Testing a full Website -> APK build

1. Start a tunnel (`cloudflared tunnel --url http://localhost:3000`) and put its https URL in `PUBLIC_BASE_URL`; restart the backend.
2. Open the frontend, upload `examples/sample-site.zip`, a name, a package and `examples/test-icon.png`.
3. Watch the progress steps; the first build takes a few minutes. Download and install the APK (enable "install unknown apps").

## 16. Deploying the backend

Run on any Node host (VM, container, Render, Fly.io, Railway) behind HTTPS. Use a persistent volume for `STORAGE_PATH` and `DATABASE_PATH`, set `NODE_ENV=production`, `PUBLIC_BASE_URL`, `TRUST_PROXY=1` behind one proxy, and run **one** instance (SQLite and the in-process queue are single-process).

## 17. Production security notes

- Builds are authorized by a 128-bit random build ID (the "link is the secret" model). Add user authentication before exposing the service to the public.
- The runner downloads inputs with a per-build token that is revoked when the build ends; the website is never executed by the backend.
- ZIPs are rejected for traversal, absolute paths, symlinks, `.exe .bat .cmd .sh .php .py`, >1000 files, >10 MB files, and sizes are checked on the real decompressed stream.
- Webhooks require a valid HMAC signature and must come from your repository and workflow.
- Uploaded sites run inside a WebView with file access from web content, cross-origin file access and JavaScript bridges disabled. `fetch()`/XHR to local files is therefore not available; inline data or use HTTPS APIs.
- Keep the repository private and restrict who can push; anyone with write access can read the signing secrets through workflow changes.
- Uploaded input files are deleted when a build completes. Failed builds keep them so they can be retried; add a cron job to purge old `uploads/builds/*` if needed.

## 18. Adding Supabase / PostgreSQL later

`backend/src/db/database.js` is the only file that talks to SQL. Create a module with the same methods (`insertBuild`, `getBuild`, `updateBuild`, `claimQueued`, `countByStatus`, `listQueued`, `listByStatus`, `queuePosition`, `close`) backed by `pg` (use `UPDATE ... WHERE status='queued' RETURNING` for `claimQueued`), and select it in `createDatabase`. `BuildService` already awaits every call.

## 19. Adding S3 storage later

`backend/src/services/storage.js` documents the storage interface. Implement `putFile`, `putBuffer`, `createReadStream`, `stat`, `delete`, `deletePrefix` and `getDownloadUrl` (return a presigned URL; the download route then redirects to it) with the AWS SDK or Supabase client, add it to `createStorage()`, and set `STORAGE_DRIVER`.

## Gradle wrapper note

The binary `gradle-wrapper.jar` is not committed. CI installs Gradle 8.7 (checksum verified) and calls `gradle` directly. Locally run `gradle wrapper --gradle-version 8.7` inside `android-template/` once if you want `./gradlew`.
